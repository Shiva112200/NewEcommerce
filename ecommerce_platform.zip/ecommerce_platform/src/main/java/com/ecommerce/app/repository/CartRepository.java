package com.ecommerce.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommerce.app.entity.Cart;
import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Long> {

    // Get cart items by user
    List<Cart> findByUser_UserId(Long userId);
}
