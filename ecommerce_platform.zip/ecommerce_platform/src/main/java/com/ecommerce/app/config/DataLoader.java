package com.ecommerce.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.UserRepository;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) {

        // check if admin already exists using username
        if (userRepository.findByUsername("admin").isEmpty()) {

            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123"); // plain password (for demo)
            admin.setRole("ADMIN");
            admin.setEmail("admin@gmail.com");

            userRepository.save(admin);

            System.out.println("✅ Admin created successfully");
        }
    }
}
