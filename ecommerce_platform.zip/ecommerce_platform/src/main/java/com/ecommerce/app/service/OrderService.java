package com.ecommerce.app.service;

import com.ecommerce.app.entity.*;
import com.ecommerce.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private CartService cartService;

    // Create Order
    public String createOrder(User user) {

        List<Cart> cartItems = cartRepo.findByUser_UserId(user.getUserId());

        if (cartItems.isEmpty()) {
            return "Cart is empty";
        }

        Order order = new Order();
        order.setUser(user);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDate.now());

        List<OrderItem> items = new ArrayList<>();
        double total = 0;

        for (Cart cart : cartItems) {

            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(cart.getProduct());
            item.setQuantity(cart.getQuantity());
            item.setPrice(cart.getProduct().getPrice());

            total += item.getQuantity() * item.getPrice();
            items.add(item);
        }

        order.setItems(items);
        order.setTotalAmount(total);

        orderRepo.save(order);

        // Clear cart
        cartService.clearCart();

        return "✅ Order Created Successfully";
    }

    // Get Order
    public Order getOrderDetails(Long orderId) {
        return orderRepo.findById(orderId).orElseThrow();
    }

    // Get All Orders
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    // Update Status
    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderRepo.findById(orderId).orElseThrow();
        order.setStatus(status);
        orderRepo.save(order);
    }
}
