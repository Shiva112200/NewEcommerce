package com.ecommerce.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommerce.app.entity.Product;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    // Filter products by category
    List<Product> findByCategory_CategoryId(Long categoryId);
}
