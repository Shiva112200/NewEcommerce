package com.ecommerce.app.controller;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.entity.Order;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.service.OrderService;
import com.ecommerce.app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
@CrossOrigin("*")
public class OrderController {

    @Autowired
    private OrderService service;

    @Autowired
    private UserService userService;

    // Create order
    @PostMapping("/{userId}")
    public String createOrder(@PathVariable Long userId) {
        User user = userService.getUserProfile(userId);
        return service.createOrder(user);
    }

    // Get order by ID
    @GetMapping("/{orderId}")
    public Order getOrder(@PathVariable Long orderId) {
        return service.getOrderDetails(orderId);
    }

    // Get all orders
    @GetMapping
    public List<Order> getAll() {
    	if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("❌ Only ADMIN can do get all product");
		}

        return service.getAllOrders();
    }
}
