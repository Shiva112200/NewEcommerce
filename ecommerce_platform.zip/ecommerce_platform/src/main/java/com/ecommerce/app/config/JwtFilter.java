package com.ecommerce.app.config;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class JwtFilter implements Filter {

	@Autowired
	private JwtUtil jwtUtil;

	public static String currentRole = "";

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		String path = req.getRequestURI();

		// ✅ Allow login & register without token
		if (path.contains("/users/login") || path.contains("/users/register") || path.contains("/api/payment/success")
				|| path.contains("/api/payment/cancel")) {
			chain.doFilter(request, response);
			return;
		}

		String header = req.getHeader("Authorization");

		// ❌ No token → BLOCK
		if (header == null || !header.startsWith("Bearer ")) {
			res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			res.getWriter().write("❌ Token required");
			return;
		}

		String token = header.substring(7);

		try {
			currentRole = jwtUtil.getRole(token);
		} catch (Exception e) {
			res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			res.getWriter().write("❌ Invalid token");
			return;
		}

		chain.doFilter(request, response);
	}
}
