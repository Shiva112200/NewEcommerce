package com.ecommerce.app.controller;

import com.ecommerce.app.entity.Payment;
import com.ecommerce.app.service.PaymentService;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/create-checkout-session/{orderId}")
    public ResponseEntity<Map<String, Object>> createCheckoutSession(
            @PathVariable Long orderId
    ) throws StripeException {

        Long amount = (long) paymentService.getOrderAmount(orderId);

        SessionCreateParams params =
                SessionCreateParams.builder()

                        .addPaymentMethodType(
                                SessionCreateParams.PaymentMethodType.CARD
                        )

                        .setMode(SessionCreateParams.Mode.PAYMENT)

                        .setSuccessUrl(
                                "http://localhost:8085/api/payment/success/" + orderId
                        )

                        .setCancelUrl(
                                "http://localhost:8085/api/payment/cancel"
                        )

                        .addLineItem(
                                SessionCreateParams.LineItem.builder()
                                        .setQuantity(1L)

                                        .setPriceData(
                                                SessionCreateParams.LineItem.PriceData.builder()
                                                        .setCurrency("usd")
                                                        .setUnitAmount(amount * 100)

                                                        .setProductData(
                                                                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                        .setName("Order Payment")
                                                                        .build()
                                                        )
                                                        .build()
                                        )
                                        .build()
                        )
                        .build();

        Session session = Session.create(params);

        Map<String, Object> responseData = new HashMap<>();

        responseData.put("sessionId", session.getId());
        responseData.put("url", session.getUrl());

        return ResponseEntity.ok(responseData);
    }

    @GetMapping("/success/{orderId}")
    public String success(@PathVariable Long orderId) {

        Payment payment = paymentService.processPayment(orderId);

        return "Payment Successful. Payment ID: " + payment.getPaymentId();
    }

    @GetMapping("/cancel")
    public String cancel() {
        return "Payment Cancelled";
    }
}