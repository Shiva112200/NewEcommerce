package com.ecommerce.app.config;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    // Secret key
    private final Key key =
            Keys.hmacShaKeyFor(
                    "mySecretKeymySecretKeymySecretKey12".getBytes()
            );

    // Generate token
    public String generateToken(String userId, String role) {

        return Jwts.builder()

                .setSubject(userId)

                .claim("role", role)

                .setIssuedAt(new Date())

                // Token valid for 1 hour
                .setExpiration(
                        new Date(System.currentTimeMillis() + 1000 * 60 * 60)
                )

                .signWith(key, SignatureAlgorithm.HS256)

                .compact();
    }

    // Extract all claims
    private Claims extractClaims(String token) {

        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // Get userId
    public String getUserId(String token) {
        return extractClaims(token).getSubject();
    }

    // Get role
    public String getRole(String token) {
        return (String) extractClaims(token).get("role");
    }

    // Check expiration
    public boolean isTokenExpired(String token) {

        return extractClaims(token)
                .getExpiration()
                .before(new Date());
    }

    // Validate token
    public boolean validateToken(String token) {

        try {

            return !isTokenExpired(token);

        } catch (JwtException | IllegalArgumentException e) {

            return false;
        }
    }
}