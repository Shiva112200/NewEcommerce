package com.ecommerce.app.service;

import com.ecommerce.app.entity.*;
import com.ecommerce.app.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private ProductRepository productRepo;

    // Get order amount
    public double getOrderAmount(Long orderId) {

        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        return order.getTotalAmount();
    }

    // Process payment
    public Payment processPayment(Long orderId) {

        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // Prevent duplicate payment
        if (paymentRepo.findByOrder_OrderId(orderId).isPresent()) {
            throw new RuntimeException("Payment already completed");
        }

        // Check and reduce stock
        for (OrderItem item : order.getItems()) {

            Product product = item.getProduct();

            if (product.getStockQuantity() < item.getQuantity()) {
                throw new RuntimeException(
                        "Insufficient stock for product: "
                                + product.getName()
                );
            }

            product.setStockQuantity(
                    product.getStockQuantity() - item.getQuantity()
            );

            productRepo.save(product);
        }

        // Create payment
        Payment payment = new Payment();

        payment.setOrder(order);
        payment.setAmount(order.getTotalAmount());
        payment.setPaymentStatus("SUCCESS");
        payment.setPaymentDate(LocalDate.now());

        // Update order status
        order.setStatus("PAID");

        orderRepo.save(order);

        return paymentRepo.save(payment);
    }

    // Get payment status
    public Payment getPaymentStatus(Long paymentId) {

        return paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }
}